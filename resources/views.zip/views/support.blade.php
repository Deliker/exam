@extends('layouts.app')

@section('content')
    <div class="support-content">
        <h2>Support</h2>
        <p>For any support, please contact us at support@casinoslotwars.com</p>
    </div>
@endsection
